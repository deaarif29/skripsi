/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pegawai;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.sesion;
import koneksi.koneksi;
/**
 *
 * @author d
 */
public class pegawai extends javax.swing.JPanel {
    String sql;
    Statement stat;
    ResultSet rs;

    String nip = sesion.getU_nip();

    /**
     * Creates new form pegawai
     */
    public pegawai() {
        initComponents();
        data();
        buka();
        jabatan();
        txtnip.setVisible(false);
    }
     private void jabatan(){
        cbjabatan.removeAllItems();
        cbjabatan.addItem("Pilih");
        cbjabatan.addItem("Staff Ekbang");
        cbjabatan.addItem("Staff Pelayanan");
    }
     
     private void refresh() {
        data();
        bttambah.setEnabled(true);

        btbatal.setEnabled(false);
        bthapus.setEnabled(false);
        btubah.setEnabled(false);
        btsimpan.setEnabled(false);

        txtnipp.setText("");
        txtnama.setText("");
        cbjabatan.setSelectedItem("Pilih");
        txtalamat.setText("");
        txttelepon.setText("");
        txtnip.setText("");
    }
     
     private void bersih() {
        txtnipp.setText("");
        txtnama.setText("");
        cbjabatan.setSelectedItem("Pilih");
        txtalamat.setText("");
        txttelepon.setText("");
        txtnip.setText("");
    }
     
     private void buka() {
        bttambah.setEnabled(true);
        btbatal.setEnabled(false);
        btsimpan.setEnabled(false);
        btubah.setEnabled(false);
        bthapus.setEnabled(false);

        txtnipp.setEnabled(false);
        txtnama.setEnabled(false);
        cbjabatan.setEnabled(false);
        txtalamat.setEnabled(false);
        txttelepon.setEnabled(false);
        txtnip.setEnabled(false);
    }
     
     private void kunci() {
        btsimpan.setEnabled(false);

        txtnipp.setEnabled(false);
        txtnama.setEnabled(false);
        cbjabatan.setEnabled(false);
        txtalamat.setEnabled(false);
        txttelepon.setEnabled(false);
        txtnip.setEnabled(false);
    }
     
     private void baru() {
        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(true);

        txtnipp.setEnabled(true);
        txtnama.setEnabled(true);
        cbjabatan.setEnabled(true);
        txtalamat.setEnabled(true);
        txttelepon.setEnabled(true);
        txtnip.setEnabled(false);
        txtnip.setText(String.valueOf(nip));
    }
     
      public void data() {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("NIP");
        tbl.addColumn("Nama");
        tbl.addColumn("Jabatan");
        tbl.addColumn("Alamat");
        tbl.addColumn("Telepon");
        tbl.addColumn("By NIP");
        tbl.addColumn("Date");
        jTable1.setModel(tbl);
        try {
            Statement statement = (Statement) koneksi.GetConnection().createStatement();
            ResultSet res = statement.executeQuery("SELECT * FROM pegawai ORDER BY nip ASC");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("nip"),
                    res.getString("nama"),
                    res.getString("jabatan"),
                    res.getString("alamat"),
                    res.getString("telepon"),
                    res.getString("createby_nip"),
                    res.getString("createdate")
                });
                jTable1.setModel(tbl);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database" + e);
        }
    }
      
      private void simpan() {
        String a, b, c, d, f, g;
        a = txtnipp.getText();
        b = txtnama.getText();
        g = cbjabatan.getSelectedItem().toString();
        c = txtalamat.getText();
        d = txttelepon.getText();
        f = txtnip.getText();
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate("INSERT INTO pegawai (no, nip, nama, jabatan, alamat, telepon, createby_nip) VALUES (no,'" + a + "','" + b + "','" + g + "','" + c + "','" + d + "','" + f + "');");
            }
            refresh();
            kunci();
            data();
            JOptionPane.showMessageDialog(null, "Data Berhasil disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal disimpan! Periksa Database" + e);
        }
    }
      
      
    private void ubah() {
        String a, b, c, d, f,g;
        a = txtnipp.getText();
        b = txtnama.getText();
        g = cbjabatan.getSelectedItem().toString();
        c = txtalamat.getText();
        d = txttelepon.getText();
        f = txtnip.getText();
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate("update pegawai set nip='" + a + "',nama='" + b + "',jabatan='" + g + "' ,alamat='" + c + "', telepon='" + d + "' ,createby_nip='" + f + "' where nip='" + a + "'");
            }
            data();
            JOptionPane.showMessageDialog(null, "Data Berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal diubah! Periksa Database" + e);
        }
        refresh();
        kunci();
    }
    
    private void hapus() {
        sql = "DELETE FROM pegawai WHERE nip='" + txtnipp.getText() + "'";
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate(sql);
            }
            JOptionPane.showMessageDialog(null, "Data Berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal dihapus! Periksa Database" + e);
        }
        refresh();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtnipp = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        cbjabatan = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtalamat = new javax.swing.JTextArea();
        txttelepon = new javax.swing.JTextField();
        bttambah = new javax.swing.JButton();
        btubah = new javax.swing.JButton();
        bthapus = new javax.swing.JButton();
        btbatal = new javax.swing.JButton();
        btsimpan = new javax.swing.JButton();
        txtnip = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jLabel1.setText("DATA PEGAWAI");

        jLabel2.setText("NIP");

        jLabel3.setText("NAMA");

        jLabel4.setText("JABATAN");

        jLabel5.setText("ALAMAT");

        jLabel6.setText("TELEPON");

        cbjabatan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtalamat.setColumns(20);
        txtalamat.setRows(5);
        jScrollPane1.setViewportView(txtalamat);

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btubah.setText("UBAH");
        btubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btubahActionPerformed(evt);
            }
        });

        bthapus.setText("HAPUS");
        bthapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthapusActionPerformed(evt);
            }
        });

        btbatal.setText("BATAL");
        btbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbatalActionPerformed(evt);
            }
        });

        btsimpan.setText("SIMPAN");
        btsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsimpanActionPerformed(evt);
            }
        });

        jLabel7.setText("CARI DATA");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addGap(18, 18, 18)
                            .addComponent(cbjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel2))
                            .addGap(34, 34, 34)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtnipp, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtnama)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(22, 22, 22)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addGap(18, 18, 18)
                            .addComponent(txttelepon, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bttambah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btbatal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btsimpan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btubah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bthapus))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(176, 176, 176)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtnipp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txttelepon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btubah)
                    .addComponent(bthapus)
                    .addComponent(btbatal)
                    .addComponent(btsimpan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsimpanActionPerformed
        // TODO add your handling code here:
         int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Menyimpan ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            simpan();
            data();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
        }
    }//GEN-LAST:event_btsimpanActionPerformed

    private void btubahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btubahActionPerformed
        // TODO add your handling code here:
         int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Mengubah ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            ubah();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);
        }
    }//GEN-LAST:event_btubahActionPerformed

    private void bthapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthapusActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Menghapus ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            hapus();
        } else {
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);
        }
        bersih();
        kunci();           
    }//GEN-LAST:event_bthapusActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        txtnipp.setEnabled(true);
        txtnama.setEnabled(true);   
        cbjabatan.setEnabled(true);
        txtalamat.setEnabled(true);
        txttelepon.setEnabled(true);
        txtnip.setEnabled(false);
        txtnip.setText(String.valueOf(nip));
        
        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(false);
        btubah.setEnabled(true);
        bthapus.setEnabled(true);
        try {
            int row = jTable1.rowAtPoint(evt.getPoint());
            txtnipp.setText(jTable1.getValueAt(row, 0).toString());
            txtnama.setText(jTable1.getValueAt(row, 1).toString());
            cbjabatan.setSelectedItem(jTable1.getValueAt(row, 2).toString());
            txtalamat.setText(jTable1.getValueAt(row, 3).toString());
            txttelepon.setText(jTable1.getValueAt(row, 4).toString());
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        // TODO add your handling code here:
        baru();
    }//GEN-LAST:event_bttambahActionPerformed

    private void btbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbatalActionPerformed
        // TODO add your handling code here:
        buka();
        bersih();
    }//GEN-LAST:event_btbatalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbatal;
    private javax.swing.JButton bthapus;
    private javax.swing.JButton btsimpan;
    private javax.swing.JButton bttambah;
    private javax.swing.JButton btubah;
    private javax.swing.JComboBox<String> cbjabatan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextArea txtalamat;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtnip;
    private javax.swing.JTextField txtnipp;
    private javax.swing.JTextField txttelepon;
    // End of variables declaration//GEN-END:variables
}
