/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

/**
 *
 * @author d
 */
public class sesion {
    private static String u_nip;
    private static String u_nama;
    private static String u_status;
    
    public static String getU_nip() {
        return u_nip;
    }
    public static void setU_nip(String aU_nip) {
        u_nip = aU_nip;
    }

    public static String getU_nama() {
    return u_nama;
    }
    
    public static void setU_nama(String aU_nama) {
        u_nama = aU_nama;
    }
    
    public static String getU_noregister() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public static String getU_status() {
        return u_status;
    }
    
    public static void setU_status(String aU_status) {
        u_status = aU_status;
    }

}