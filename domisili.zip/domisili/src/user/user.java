/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;
import cari.caripegawai;
import cari.caripegawaiclass;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.sesion;
import koneksi.koneksi;
/**
 *
 * @author d
 */
public class user extends javax.swing.JPanel {
    String sql;
    Statement stat;
    ResultSet rs;

    String nip = sesion.getU_nip();
    /**
     * Creates new form user
     */
    public user() {
        initComponents();
        data();
        buka();
        register();
        txtnip.setVisible(false);
    
    }
    
    private void register(){
        cbstatus.removeAllItems();
        cbstatus.addItem("Pilih");
        cbstatus.addItem("staff Ekbang");
        cbstatus.addItem("Pelayanan");
    }
    
    private void refresh() {
        data();
        bttambah.setEnabled(true);

        btbatal.setEnabled(false);
        bthapus.setEnabled(false);
        btubah.setEnabled(false);
        btsimpan.setEnabled(false);

        cbnip.setText("");
        cbstatus.setSelectedItem("");
        txtusername.setText("");
        txtpassword.setText("");
        txtnip.setText("");
    }
    
    private void bersih() {
        cbnip.setText("");
        cbstatus.setSelectedItem("");
        txtusername.setText("");
        txtpassword.setText("");
        txtnip.setText("");
    }
     
    private void buka() {
        bttambah.setEnabled(true);
        btbatal.setEnabled(false);
        btsimpan.setEnabled(false);
        btubah.setEnabled(false);
        bthapus.setEnabled(false);

        btcarii.setEnabled(false);
        cbnip.setEnabled(false);
        cbstatus.setEnabled(false);
        txtusername.setEnabled(false);
        txtpassword.setEnabled(false);
        txtnip.setEnabled(false);
    }
     
    private void kunci() {
        btsimpan.setEnabled(false);
        btcarii.setEnabled(false);
        cbnip.setEnabled(false);
        cbstatus.setEnabled(false);
        txtusername.setEnabled(false);
        txtpassword.setEnabled(false);
        txtnip.setEnabled(false);
    }
      
    private void baru() {
        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(true);

        btcarii.setEnabled(true);
        cbnip.setEnabled(false);
        cbstatus.setEnabled(true);
        txtusername.setEnabled(true);
        txtpassword.setEnabled(true);
        txtnip.setEnabled(false);
        txtnip.setText(String.valueOf(nip));
    }
      
    public void data() {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("NIP");
        tbl.addColumn("Status");
        tbl.addColumn("Username");
        tbl.addColumn("Password");
        tbl.addColumn("By NIP");
        tbl.addColumn("Date");
        jTable1.setModel(tbl);
        try {
            Statement statement = (Statement) koneksi.GetConnection().createStatement();
            ResultSet res = statement.executeQuery("SELECT * FROM user ORDER BY nip ASC");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("nip"),
                    res.getString("status"),
                    res.getString("username"),
                    res.getString("password"),
                    res.getString("createby_nip"),
                    res.getString("createdate")
                });
                jTable1.setModel(tbl);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database" + e);
        }
    }
    
    private void simpan() {
        String a, b, c, d, f;
        a = cbnip.getText();
        b = cbstatus.getSelectedItem().toString();
        c = txtusername.getText();
        d = txtpassword.getText();
        f = txtnip.getText();
        if (txtnip.getText().trim().equals("null")) {
            JOptionPane.showMessageDialog(null, "Maaf, Login terlebih dahulu!");
        } else {
            try {
                try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                    statement.executeUpdate("INSERT INTO user (no, nip, status, username, password, createby_nip) VALUES (no,'" + a + "','" + b + "','" + c + "',md5('" + d + "'),'" + f + "');");
                }
                data();
                refresh();
                kunci();
                JOptionPane.showMessageDialog(null, "Data Berhasil disimpan");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Data Gagal disimpan! Periksa Database" + e);
            }
        }
    }
     
    private void ubah() {
        String a, b, c, d, f;
        a = cbnip.getText();
        b = cbstatus.getSelectedItem().toString();
        c = txtusername.getText();
        d = txtpassword.getText();
        f = txtnip.getText();
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate("update user set nip='" + a + "',status='" + b + "',username='" + c + "', password='" + d + "' ,createby_nip='" + f + "' where nip='"+a+"'");
            }
            data();
            JOptionPane.showMessageDialog(null, "Data diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal diubah! Periksa Database" + e);
        }
        refresh();
        kunci();
    }
    
    private void hapus() {
        sql = "DELETE FROM user WHERE nip='" + cbnip.getText() + "'";
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate(sql);
            }
            JOptionPane.showMessageDialog(null, "Data dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal dihapus! Periksa Database" + e);
        }
        refresh();
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        bttambah = new javax.swing.JButton();
        btbatal = new javax.swing.JButton();
        btsimpan = new javax.swing.JButton();
        btubah = new javax.swing.JButton();
        bthapus = new javax.swing.JButton();
        cbnip = new javax.swing.JTextField();
        cbstatus = new javax.swing.JComboBox<>();
        txtusername = new javax.swing.JTextField();
        txtpassword = new javax.swing.JTextField();
        txtnip = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtnipp = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btcarii = new javax.swing.JButton();

        jLabel1.setText("DATA USER");

        jLabel2.setText("NIP");

        jLabel3.setText("STATUS");

        jLabel4.setText("USERNAME");

        jLabel5.setText("PASSWORD");

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btbatal.setText("BATAL");
        btbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbatalActionPerformed(evt);
            }
        });

        btsimpan.setText("SIMPAN");
        btsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsimpanActionPerformed(evt);
            }
        });

        btubah.setText("UBAH");
        btubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btubahActionPerformed(evt);
            }
        });

        bthapus.setText("HAPUS");
        bthapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthapusActionPerformed(evt);
            }
        });

        cbstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setText("CARI DATA");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btcarii.setText("CARI");
        btcarii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcariiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 634, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(bttambah)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btbatal)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btsimpan)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btubah)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bthapus))
                                    .addComponent(txtnipp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtusername, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbnip, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtpassword, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btcarii)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btcarii)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addComponent(txtpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btbatal)
                    .addComponent(btsimpan)
                    .addComponent(btubah)
                    .addComponent(bthapus))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtnipp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        cbnip.setEnabled(false);
        cbstatus.setEnabled(true);
        txtusername.setEnabled(true);
        txtpassword.setEnabled(true);
        txtnip.setEnabled(false);
        txtnip.setText(String.valueOf(nip));

        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(false);
        btubah.setEnabled(true);
        bthapus.setEnabled(true);

        try {
            int row = jTable1.rowAtPoint(evt.getPoint());
            cbnip.setText(jTable1.getValueAt(row, 0).toString());
            cbstatus.setSelectedItem(jTable1.getValueAt(row, 1).toString());
            txtusername.setText(jTable1.getValueAt(row, 2).toString());
            txtpassword.setText(jTable1.getValueAt(row, 3).toString());

        } catch (Exception e) {
      }
                                       

    }//GEN-LAST:event_jTable1MouseClicked

    private void btsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsimpanActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "simpan data?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            simpan();
            data();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
        }
    }//GEN-LAST:event_btsimpanActionPerformed

    private void btubahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btubahActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Mengubah ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            ubah();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);

        }
    }//GEN-LAST:event_btubahActionPerformed

    private void bthapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthapusActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Hapus data User?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            hapus();
        } else {
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);

        }
        bersih();
        kunci();
    }//GEN-LAST:event_bthapusActionPerformed

    private void btcariiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcariiActionPerformed
        // TODO add your handling code here:
        caripegawai cari = new caripegawai(new javax.swing.JFrame(), true);
        cari.setVisible(true);
        caripegawaiclass cr = cari.gettabledata();
        if (cr != null) {
            cbnip.setText(cr.getId());
            txtnip.requestFocus();
        }
    }//GEN-LAST:event_btcariiActionPerformed

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        // TODO add your handling code here:
        baru();
    }//GEN-LAST:event_bttambahActionPerformed

    private void btbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbatalActionPerformed
        // TODO add your handling code here:
        buka();
        bersih();
    }//GEN-LAST:event_btbatalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbatal;
    private javax.swing.JButton btcarii;
    private javax.swing.JButton bthapus;
    private javax.swing.JButton btsimpan;
    private javax.swing.JButton bttambah;
    private javax.swing.JButton btubah;
    private javax.swing.JTextField cbnip;
    private javax.swing.JComboBox<String> cbstatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtnip;
    private javax.swing.JTextField txtnipp;
    private javax.swing.JTextField txtpassword;
    private javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
