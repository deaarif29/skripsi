/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cari;

/**
 *
 * @author d
 */
public class caridaftarclass {
    private String id;
    private String na;
    
    public caridaftarclass(String kd, String nama){
        this.id = kd;
        this.na = nama;
    }
    
    public caridaftarclass(){
        
    }
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getNa() {
        return na;
    }
    public void setNa(String na) {
        this.na = na;
    } 
}
