/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cari;

/**
 *
 * @author d
 */
public class cariregisterclass {
    private String id;
    private String na;
    private String ta;
    private String ja;
    
    public cariregisterclass(String nip, String nama, String tanggal, String jenis){
        this.id = nip;
        this.na = nama;  
        this.ta = tanggal;   
        this.ja = jenis; 
    }

    public cariregisterclass(){    
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getNa() {
        return na;
    }
    
    public void setNa(String na) {
        this.na = na;
    }
    
     public String getTa() {
        return ta;
    }

    public void setTa(String ta) {
        this.ta = ta;
    }
    
    public String getJa() {
        return ja;
    }
    
    public void setJa(String ja) {
        this.ja = ja;
    }
}