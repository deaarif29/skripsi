/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cari;

/**
 *
 * @author d
 */
public class caripegawaiclass {
    private String id;
    private String na;
 
    public caripegawaiclass(String nip, String nama){
        this.id = nip;
        this.na = nama;    
    }
    public caripegawaiclass(){
    
    }
    
    public String getId() {
        return id;
    }
    
     public void setId(String id) {
        this.id = id;
    }
     
    public String getNa() {
        return na;
    }
    
    public void setNa(String na) {
        this.na = na;
    }
    
}
