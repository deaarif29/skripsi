/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input;

import cari.caridaftar;
import cari.caridaftarclass;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.sesion;
import koneksi.koneksi;

/**
 *
 * @author d
 */
public class input extends javax.swing.JPanel {
    
    String sql;
    Statement stat;
    ResultSet rs;

    String nip = sesion.getU_nip();
    

    /**
     * Creates new form input
     */
    public input() {
        initComponents();
        data();
        bidang();
        kelurahan();
        buka();
        txtnip.setVisible(false);
    }
    
     private void bidang(){
        cbbidang.removeAllItems();
        cbbidang.addItem("Pilih");
        cbbidang.addItem("Ekstraktif");
        cbbidang.addItem("Industri");
        cbbidang.addItem("Pperdagangan");
        cbbidang.addItem("Jasa");
    }
     
    private void kelurahan(){
        cbkel.removeAllItems();
        cbkel.addItem("Pilih");
        cbkel.addItem("Hegarmanah");
        cbkel.addItem("Ciumbuleuit");
        cbkel.addItem("Ledeng");
    }
    
    private void kepemilikan(){
        cbkel.removeAllItems();
        cbkel.addItem("Pilih");
        cbkel.addItem("Hegarmanah");
        cbkel.addItem("Ciumbuleuit");
        cbkel.addItem("Ledeng");
    }
    
    private void refresh() {
        data();
        otomatis();
        bttambah.setEnabled(true);
        btbatal.setEnabled(false);
        bthapus.setEnabled(false);
        btubah.setEnabled(false);
        btsimpan.setEnabled(false);

        txtno.setText("");
        txtnik.setText("");
        txtnama.setText("");
        txttempat.setText("");
        cbtanggal.setCalendar(null);
        txtalamatdir.setText("");
        txtperusahaan.setText("");
        txttlp.setText("");
        txtnoakta.setText("");
        cbkepemilikan.setSelectedItem("");
        txtjam1.setText("");
        txtjam2.setText("");
        txtjumlah.setText("");
        cbbidang.setSelectedItem("");
        txtket.setText("");
        txtalamatper.setText("");
        txtrt.setText("");
        txtrw.setText("");
        cbkel.setSelectedItem("Pilih");
        txtnip.setText("");
    }
    
    private void bersih() {
    txtno.setText("");
        txtnik.setText("");
        txtnama.setText("");
        txttempat.setText("");
        cbtanggal.setCalendar(null);
        txtalamatdir.setText("");
        txtperusahaan.setText("");
        txttlp.setText("");
        txtnoakta.setText("");
        cbkepemilikan.setSelectedItem("");
        txtjam1.setText("");
        txtjam2.setText("");
        txtjumlah.setText("");
        cbbidang.setSelectedItem("");
        txtket.setText("");
        txtalamatper.setText("");
        txtrt.setText("");
        txtrw.setText("");
        cbkel.setSelectedItem("Pilih");
        txtnip.setText("");
    }
    
    private void buka() {
        bttambah.setEnabled(true);
        btbatal.setEnabled(false);
        btsimpan.setEnabled(false);
        btubah.setEnabled(false);
        bthapus.setEnabled(false);
     
        txtnik.setEnabled(false);
        txtnama.setEnabled(false);
        txttempat.setEnabled(false);
        cbtanggal.setCalendar(false);
        txtalamatdir.setEnabled(false);
        txtperusahaan.setEnabled(false);
        txttlp.setEnabled(false);
        txtnoakta.setEnabled(false);
        cbkepemilikan.setEnabled(false);
        txtjam1.setEnabled(false);
        txtjam2.setEnabled(false);
        txtjumlah.setEnabled(false);
        cbbidang.setEnabled(false);
        txtket.setEnabled(false);
        txtalamatper.setEnabled(false);
        txtrt.setEnabled(false);
        txtrw.setEnabled(false);
        cbkel.setEnabled(false);
        txtnip.setEnabled(false);
    }
    
    private void kunci() {
        btsimpan.setEnabled(false);
        
        txtnik.setEnabled(false);
        txtnama.setEnabled(false);
        txttempat.setEnabled(false);
        cbtanggal.setCalendar(false);
        txtalamatdir.setEnabled(false);
        txtperusahaan.setEnabled(false);
        txttlp.setEnabled(false);
        txtnoakta.setEnabled(false);
        cbkepemilikan.setEnabled(false);
        txtjam1.setEnabled(false);
        txtjam2.setEnabled(false);
        txtjumlah.setEnabled(false);
        cbbidang.setEnabled(false);
        txtket.setEnabled(false);
        txtalamatper.setEnabled(false);
        txtrt.setEnabled(false);
        txtrw.setEnabled(false);
        cbkel.setEnabled(false);
        txtnip.setEnabled(false);
    }
    
    private void baru() {
        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(true);
        
        txtnik.setEnabled(false);
        txtnama.setEnabled(false);
        txttempat.setEnabled(false);
        cbtanggal.setCalendar(false);
        txtalamatdir.setEnabled(false);
        txtperusahaan.setEnabled(false);
        txttlp.setEnabled(false);
        txtnoakta.setEnabled(false);
         cbkepemilikan.setEnabled(false);
        txtjam1.setEnabled(false);
        txtjam2.setEnabled(false);
        txtjumlah.setEnabled(false);
        cbbidang.setEnabled(false);
        txtket.setEnabled(false);
        txtalamatper.setEnabled(false);
        txtrt.setEnabled(false);
        txtrw.setEnabled(false);
        cbkel.setEnabled(false);
        txtnip.setEnabled(false);
    }
    
    private void otomatis() {
     sql = "SELECT RIGHT(no_register,3) AS kd FROM input";
        try {
            stat=(Statement)koneksi.GetConnection().createStatement();
            rs=stat.executeQuery(sql);
            if (rs.first() == false) {
                txtno.setText("18001");
            } else if (rs.first() == false) {
                txtno.setText("180001");
            } else {
                rs.last();
                int no = rs.getInt(1) + 1;
                String cno = String.valueOf(no);
                int pjg_cno = cno.length();
                for (int i = 0; i < 3 - pjg_cno; i++) {
                    cno = "0" + cno;
                }
                txtno.setText("18" + cno);
            }
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database"+e);
        }
    }

    public void data() {
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("No");
        tbl.addColumn("NIK");
        tbl.addColumn("Nama");
        tbl.addColumn("Tempat");
        tbl.addColumn("Tgl Lahir");
        tbl.addColumn("Alamat Direktur");
        tbl.addColumn("Perusahaan");
        tbl.addColumn("Telepon");
        tbl.addColumn("Akta");
        tbl.addColumn("Kepemilikan");
        tbl.addColumn("Jam masuk");
        tbl.addColumn("Jam keluar");
        tbl.addColumn("Akta");
        tbl.addColumn("Jumlah pegawai");
        tbl.addColumn("Bidang");
        tbl.addColumn("Keterangan");
        tbl.addColumn("Alamat");
        tbl.addColumn("RT");
        tbl.addColumn("RW");
        tbl.addColumn("Kelurahan");
        tbl.addColumn("By NIP");
        jTable1.setModel(tbl);
        try {
            Statement statement = (Statement) koneksi.GetConnection().createStatement();
            ResultSet res = statement.executeQuery("SELECT no_register, nik, nama, tempat, tanggal_lahir, alamat_dir, perusahaan, tlp, no_aktanotaris, kepemilikan, jam_masuk, jam_keluar, jumlah_pegawai, bidang, keterangan, alamat_per, rt, rw, kelurahan, createby_nip FROM domisili ORDER BY no_register ASC");
            while (res.next()) {
                tbl.addRow(new Object[]{
                    res.getString("no_register"),
                    res.getString("nik"),
                    res.getString("nama_direktur"),
                    res.getString("tempat"),
                    res.getString("tanggal_lahir"),
                    res.getString("alamat_dir"),
                    res.getString("nama_perusahaan"),
                    res.getString("tlp"),
                    res.getString("no_aktanotaris"),
                    res.getString("kepemilikan"),
                    res.getString("jam_masuk"),
                    res.getString("jam_keluar"),
                    res.getString("jumlah_pegawai"),
                    res.getString("bidang"),
                    res.getString("keterangan"),
                    res.getString("alamat_per"),
                    res.getString("rt"),
                    res.getString("rw"),
                    res.getString("kelurahan"),
                    res.getString("createby_nip")
                });
                jTable1.setModel(tbl);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database" + e);
        }
    }
    
    private void simpan() {
        String a,b,c,d,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v;
        String tampil = "yyyy-MM-dd";
        SimpleDateFormat fm = new SimpleDateFormat(tampil);
        a = txtno.getText();
        b = txtnik.getText();
        c = txtnama.getText();
        d = txttempat.getText();
        g = String.valueOf(fm.format(cbtanggal.getDate()));
        h = txtalamatdir.getText();
        i = txtperusahaan.getText();
        j = txttlp.getText();
        k = txtnoakta.getText();
        l = cbkepemilikan.getSelectedItem().toString();
        m = txtjam1.getText();
        n = txtjam2.getText();
        o = txtjumlah.getText();
        p = cbbidang.getSelectedItem().toString();
        q = txtket.getText();
        r = txtalamatper.getText();
        s = txtrt.getText();
        t = txtrw.getText();
        u = cbkel.getSelectedItem().toString();
        v = txtnip.getText();
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate("INSERT INTO penduduk (no_register, nik, nama, tempat, tanggal_lahir, alamat_dir, perusahaan, tlp, no_akta, kepemilikan, jam_masuk, jam_keluar, jumlah_pegawai, bidang, keterangan, alamat_per, rt, rw, kelurahan, createby_nip) VALUES (no,'" + a + "','" + b + "','" + c + "','" + d + "','" + g + "','" + h + "','" + i + "','" + j + "','" + k + "','" + l + "','" + m + "','" + n + "','" + o + "','" + p + "','" + q + "','" + r + "');");
            }
            refresh();
            kunci();
            data();
            JOptionPane.showMessageDialog(null, "Data Berhasil disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal disimpan! Periksa Database" + e);
        }
    }
    
    private void ubah() {
        String a,b,c,d,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v;
        String tampil = "yyyy-MM-dd";
        SimpleDateFormat fm = new SimpleDateFormat(tampil);
        
        a = txtno.getText();
        b = txtnik.getText();
        c = txtnama.getText();
        d = txttempat.getText();
        g = String.valueOf(fm.format(cbtanggal.getDate()));
        h = txtalamatdir.getText();
        i = txtperusahaan.getText();
        j = txttlp.getText();
        k = txtnoakta.getText();
        l = cbkepemilikan.getSelectedItem().toString();
        m = txtjam1.getText();
        n = txtjam2.getText();
        o = txtjumlah.getText();
        p = cbbidang.getSelectedItem().toString();
        q = txtket.getText();
        r = txtalamatper.getText();
        s = txtrt.getText();
        t = txtrw.getText();
        u = cbkel.getSelectedItem().toString();
        v = txtnip.getText();
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate("update input set no_register='" + a + "',nik='" + b + "', nama='" + c + "', tempat='" + d + "' ,tanggal_lahir='" + g + "',alamat_dir='" + h + "',perusahaan='" + i + "',tlp='" + j + "',no_akta= '" + k + "',kepemilikan='" + l +  "',jam_masuk='" + m + ",no_akta='" + n +"',jumlah_pegawai='" + o + "',bidang='" + p + "',keterangan='" + q + "',alamat_per='" + r + "',rt='" + s + "',rw='" + t + "',kelurahan='" + u + "',createby_nip='" + v + "' where no_register='" + a + "'");
            }
            data();
            JOptionPane.showMessageDialog(null, "Data Berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal diubah! Periksa Database" + e);
        }
        refresh();
        kunci();
    }
    
    private void hapus() {
        sql = "DELETE FROM input WHERE no_register='" + txtno.getText() + "'";
        try {
            try (Statement statement = (Statement) koneksi.GetConnection().createStatement()) {
                statement.executeUpdate(sql);
            }
            JOptionPane.showMessageDialog(null, "Data Berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal dihapus! Periksa Database" + e);
        }
        refresh();
    }
    
    private void carinik(){
        String temp = txtcari.getText()+"%";
        DefaultTableModel tbl= new DefaultTableModel();
        tbl.addColumn("No");
        tbl.addColumn("NIK");
        tbl.addColumn("Nama");
        tbl.addColumn("Tempat");
        tbl.addColumn("Tgl Lahir");
        tbl.addColumn("Alamat Direktur");
        tbl.addColumn("Perusahaan");
        tbl.addColumn("Telepon");
        tbl.addColumn("Akta");
        tbl.addColumn("Kepemilikan");
        tbl.addColumn("Jam masuk");
        tbl.addColumn("Jam keluar");
        tbl.addColumn("Jumlah pegawai");
        tbl.addColumn("Bidang");
        tbl.addColumn("Keterangan");
        tbl.addColumn("Alamat");
        tbl.addColumn("RT");
        tbl.addColumn("RW");
        tbl.addColumn("Kelurahan");
        tbl.addColumn("By NIP");
        jTable1.setModel(tbl);
        try{
            Statement statement=(Statement)koneksi.GetConnection().createStatement();
            ResultSet res=statement.executeQuery("SELECT * FROM input WHERE nik LIKE '"+ temp+"'");
            while(res.next())
            {
                tbl.addRow(new Object[]{
                    res.getString("no_register"),
                    res.getString("nik"),
                    res.getString("nama"),
                    res.getString("tempat"),
                    res.getString("tanggal_lahir"),
                    res.getString("alamat_dir"),
                    res.getString("perusahaan"),
                    res.getString("tlp"),
                    res.getString("no_akta"),
                    res.getString("kepemilikan"),
                    res.getString("jam_masuk"),
                    res.getString("jam_keluar"),
                    res.getString("jumlah_pegawai"),
                    res.getString("bidang"),
                    res.getString("keterangan"),
                    res.getString("alamat_per"),
                    res.getString("rt"),
                    res.getString("rw"),
                    res.getString("kelurahan"),
                    res.getString("createby_nip")
                });
                jTable1.setModel(tbl);
            }
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database"+e);
        }
    }
    
    private void carinama(){
        String temp = txtcari.getText()+"%";
        DefaultTableModel tbl= new DefaultTableModel();
        tbl.addColumn("No");
        tbl.addColumn("NIK");
        tbl.addColumn("Nama");
        tbl.addColumn("Tempat");
        tbl.addColumn("Tgl Lahir");
        tbl.addColumn("Alamat Direktur");
        tbl.addColumn("Perusahaan");
        tbl.addColumn("Telepon");
        tbl.addColumn("Akta");
        tbl.addColumn("Kepemilikan");
        tbl.addColumn("Jam masuk");
        tbl.addColumn("Jam keluar");
        tbl.addColumn("Jumlah pegawai");
        tbl.addColumn("Bidang");
        tbl.addColumn("Keterangan");
        tbl.addColumn("Alamat");
        tbl.addColumn("RT");
        tbl.addColumn("RW");
        tbl.addColumn("Kelurahan");
        tbl.addColumn("By NIP");
        jTable1.setModel(tbl);
        try{
            Statement statement=(Statement)koneksi.GetConnection().createStatement();
            ResultSet res=statement.executeQuery("SELECT * FROM input WHERE nama LIKE '"+ temp+"'");
            while(res.next())
            {
                tbl.addRow(new Object[]{
                    res.getString("no_register"),
                    res.getString("nik"),
                    res.getString("nama"),
                    res.getString("tempat"),
                    res.getString("tanggal_lahir"),
                    res.getString("alamat_dir"),
                    res.getString("perusahaan"),
                    res.getString("tlp"),
                    res.getString("no_akta"),
                    res.getString("kepemilikan"),
                    res.getString("jam_masuk"),
                    res.getString("jam_keluar"),
                    res.getString("jumlah_pegawai"),
                    res.getString("bidang"),
                    res.getString("keterangan"),
                    res.getString("alamat_per"),
                    res.getString("rt"),
                    res.getString("rw"),
                    res.getString("kelurahan"),
                    res.getString("createby_nip")
                });
                jTable1.setModel(tbl);
            }
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database"+e);
        }
    }
    
    private void cariperusahaan(){
        String temp = txtcari.getText()+"%";
        DefaultTableModel tbl= new DefaultTableModel();
        tbl.addColumn("No");
        tbl.addColumn("NIK");
        tbl.addColumn("Nama");
        tbl.addColumn("Tempat");
        tbl.addColumn("Tgl Lahir");
        tbl.addColumn("Alamat Direktur");
        tbl.addColumn("Perusahaan");
        tbl.addColumn("Telepon");
        tbl.addColumn("Akta");
        tbl.addColumn("Kepemilikan");
        tbl.addColumn("Jam masuk");
        tbl.addColumn("Jam keluar");
        tbl.addColumn("Jumlah pegawai");
        tbl.addColumn("Bidang");
        tbl.addColumn("Keterangan");
        tbl.addColumn("Alamat");
        tbl.addColumn("RT");
        tbl.addColumn("RW");
        tbl.addColumn("Kelurahan");
        tbl.addColumn("By NIP");
        jTable1.setModel(tbl);
        try{
            Statement statement=(Statement)koneksi.GetConnection().createStatement();
            ResultSet res=statement.executeQuery("SELECT * FROM input WHERE perusahaan LIKE '"+ temp+"'");
            while(res.next())
            {
                tbl.addRow(new Object[]{
                    res.getString("no_register"),
                    res.getString("nik"),
                    res.getString("nama"),
                    res.getString("tempat"),
                    res.getString("tanggal_lahir"),
                    res.getString("alamat_dir"),
                    res.getString("perusahaan"),
                    res.getString("tlp"),
                    res.getString("no_akta"),
                    res.getString("kepemilikan"),
                    res.getString("jam_masuk"),
                    res.getString("jam_keluar"),
                    res.getString("jumlah_pegawai"),
                    res.getString("bidang"),
                    res.getString("keterangan"),
                    res.getString("alamat_per"),
                    res.getString("rt"),
                    res.getString("rw"),
                    res.getString("kelurahan"),
                    res.getString("createby_nip")
                });
                jTable1.setModel(tbl);
            }
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Koneksi Database Gagal ! Periksa Database"+e);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtno = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        txttempat = new javax.swing.JTextField();
        txtnik = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtalamatdir = new javax.swing.JTextArea();
        txtperusahaan = new javax.swing.JTextField();
        txtnoakta = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txttlp = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtalamatper = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        txtrt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtrw = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cbkel = new javax.swing.JComboBox<>();
        cbbidang = new javax.swing.JComboBox<>();
        txtjumlah = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtket = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtjam1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtjam2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        cbkepemilikan = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        bttambah = new javax.swing.JButton();
        btbatal = new javax.swing.JButton();
        btsimpan = new javax.swing.JButton();
        btubah = new javax.swing.JButton();
        bthapus = new javax.swing.JButton();
        txtnip = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        cbcari = new javax.swing.JComboBox<>();
        txtcari = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setText("REGISTER DOMISILI");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(153, 153, 153));

        jLabel2.setText("NO REGISTER");

        jLabel3.setText("NIK");

        jLabel4.setText("NAMA DIREKTUR");

        jLabel5.setText("ALAMAT DIREKTUR");

        jLabel6.setText("TEMPAT, TANGGAL LAHIR");

        txtalamatdir.setColumns(20);
        txtalamatdir.setRows(5);
        jScrollPane2.setViewportView(txtalamatdir);

        jLabel10.setText("NAMA PERUSAHAAN");

        jLabel11.setText("AKTE PENDIRIAN");

        jLabel17.setText("TLP PERUSAHAAN");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addGap(47, 47, 47)
                            .addComponent(txtnama))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txttempat, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3))
                            .addGap(62, 62, 62)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtno, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtnik, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(36, 36, 36)
                            .addComponent(jScrollPane2))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10)
                                .addComponent(jLabel17))
                            .addGap(30, 30, 30)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtperusahaan)
                                .addComponent(txttlp)
                                .addComponent(txtnoakta, javax.swing.GroupLayout.Alignment.TRAILING))))
                    .addComponent(jLabel11))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txttempat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(txtperusahaan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txttlp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtnoakta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        jLabel12.setText("JUMLAH PEGAWAI");

        jLabel13.setText("BIDANG");

        jLabel14.setText("ALAMAT PERUSAHAAN");

        txtalamatper.setColumns(20);
        txtalamatper.setRows(5);
        jScrollPane4.setViewportView(txtalamatper);

        jLabel8.setText("RT");

        jLabel9.setText("RW");

        jLabel7.setText("KELURAHAN");

        cbkel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbbidang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel16.setText("KETERANGAN");

        jLabel18.setText("JAM KERJA");

        jLabel19.setText("-");

        jLabel20.setText("KEPEMILIKAN");

        cbkepemilikan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbkel, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtrt, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtrw, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel20))
                                .addGap(51, 51, 51)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cbbidang, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(txtjam1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel19)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtjam2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cbkepemilikan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(txtjumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel12))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 2, Short.MAX_VALUE)
                        .addComponent(jLabel16)
                        .addGap(48, 48, 48)
                        .addComponent(txtket, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(cbkepemilikan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtjam1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19)
                    .addComponent(txtjam2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtjumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(cbbidang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtrt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txtrw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cbkel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(153, 153, 153));

        bttambah.setText("TAMBAH");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });

        btbatal.setText("BATAL");
        btbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbatalActionPerformed(evt);
            }
        });

        btsimpan.setText("SIMPAN");
        btsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsimpanActionPerformed(evt);
            }
        });

        btubah.setText("UBAH");
        btubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btubahActionPerformed(evt);
            }
        });

        bthapus.setText("HAPUS");
        bthapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bttambah)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btbatal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btsimpan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btubah, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bthapus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttambah)
                    .addComponent(btbatal)
                    .addComponent(btsimpan)
                    .addComponent(btubah)
                    .addComponent(bthapus)
                    .addComponent(txtnip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable1);

        jLabel15.setText("PENCARIAN");

        cbcari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });
        txtcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtcariKeyReleased(evt);
            }
        });

        jButton6.setText("CARI");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cbcari, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton6))
                            .addComponent(jLabel15)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 764, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(104, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(74, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 695, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsimpanActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Menyimpan ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            simpan();
            data();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
        }
    }//GEN-LAST:event_btsimpanActionPerformed

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        // TODO add your handling code here:
        baru();
        otomatis();
    }//GEN-LAST:event_bttambahActionPerformed

    private void btbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbatalActionPerformed
        // TODO add your handling code here:
        buka();
        bersih();
    }//GEN-LAST:event_btbatalActionPerformed

    private void bthapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthapusActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Menghapus ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            hapus();
        } else {
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);
        }
        bersih();
        kunci();
    }//GEN-LAST:event_bthapusActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        txtnik.setEnabled(true);
        txtnama.setEnabled(true);
        txttempat.setEnabled(true);
        cbtanggal.setCalendar(true);
        txtalamatdir.setEnabled(true);
        txtperusahaan.setEnabled(true);
        txttlp.setEnabled(true);
        txtnoakta.setEnabled(true);
        cbkepemilikan.setEnabled(true);
        txtjam1.setEnabled(true);
        txtjam2.setEnabled(true);
        txtjumlah.setEnabled(true);
        cbbidang.setEnabled(true);
        txtket.setEnabled(true);
        txtalamatper.setEnabled(true);
        txtrt.setEnabled(true);
        txtrw.setEnabled(true);
        cbkel.setEnabled(true);
        txtnip.setText(String.valueOf(nip));
        
        bttambah.setEnabled(false);
        btbatal.setEnabled(true);
        btsimpan.setEnabled(false);
        btubah.setEnabled(true);
        bthapus.setEnabled(true);
        
        try{
            int row = jTable1.rowAtPoint(evt.getPoint());
            SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
            Date dateValue = null;
            txtno.setText(jTable1.getValueAt(row, 0).toString());
            txtnik.setText(jTable1.getValueAt(row, 1).toString());
            txtnama.setText(jTable1.getValueAt(row, 2).toString());  
            txttempat.setText(jTable1.getValueAt(row, 3).toString());
            dateValue = date.parse((String) jTable1.getValueAt(row, 4));
            cbtanggal.setDate(dateValue);
            txtalamatdir.setText(jTable1.getValueAt(row, 5).toString());
            txtperusahaan.setText(jTable1.getValueAt(row, 6).toString());
            txttlp.setText(jTable1.getValueAt(row, 7).toString());
            txtnoakta.setText(jTable1.getValueAt(row, 8).toString());
            cbkepemilikan.setSelectedItem(jTable1.getValueAt(row, 9).toString());
            txtjam1.setText(jTable1.getValueAt(row, 10).toString());
            txtjam2.setText(jTable1.getValueAt(row, 11).toString());
            txtjumlah.setText(jTable1.getValueAt(row, 12).toString());
            cbbidang.setSelectedItem(jTable1.getValueAt(row, 13).toString());
            txtket.setText(jTable1.getValueAt(row, 14).toString());
            txtalamatper.setText(jTable1.getValueAt(row, 15).toString());
            txtrt.setText(jTable1.getValueAt(row, 16).toString());
            txtrw.setText(jTable1.getValueAt(row, 17).toString());
            cbkel.setSelectedItem(jTable1.getValueAt(row, 18).toString());
        }catch(Exception e){
        }                                   

    }//GEN-LAST:event_jTable1MouseClicked

    private void btubahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btubahActionPerformed
        // TODO add your handling code here:
        int Pilih = JOptionPane.showConfirmDialog(null, "Anda Akan Mengubah ?", "Messege", JOptionPane.YES_NO_OPTION);
        if (Pilih == JOptionPane.YES_OPTION) {
            ubah();
        } else {
            bersih();
            kunci();
            bttambah.setEnabled(true);
            btbatal.setEnabled(false);
            btubah.setEnabled(false);
            bthapus.setEnabled(false);
        }
    }//GEN-LAST:event_btubahActionPerformed

    private void txtcariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcariKeyReleased
        // TODO add your handling code here:
        if(cbcari.getSelectedItem() == "NIK"){ 
           carinik(); 
        }if(cbcari.getSelectedItem() == "perusahaan"){
           cariperusahaan();
        }else{
            carinama();
        }
         
    }//GEN-LAST:event_txtcariKeyReleased

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcariActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbatal;
    private javax.swing.JButton bthapus;
    private javax.swing.JButton btsimpan;
    private javax.swing.JButton bttambah;
    private javax.swing.JButton btubah;
    private javax.swing.JComboBox<String> cbbidang;
    private javax.swing.JComboBox<String> cbcari;
    private javax.swing.JComboBox<String> cbkel;
    private javax.swing.JComboBox<String> cbkepemilikan;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea txtalamatdir;
    private javax.swing.JTextArea txtalamatper;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtjam1;
    private javax.swing.JTextField txtjam2;
    private javax.swing.JTextField txtjumlah;
    private javax.swing.JTextField txtket;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtnik;
    private javax.swing.JTextField txtnip;
    private javax.swing.JTextField txtno;
    private javax.swing.JTextField txtnoakta;
    private javax.swing.JTextField txtperusahaan;
    private javax.swing.JTextField txtrt;
    private javax.swing.JTextField txtrw;
    private javax.swing.JTextField txttempat;
    private javax.swing.JTextField txttlp;
    // End of variables declaration//GEN-END:variables
}
